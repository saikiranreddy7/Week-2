import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superhero2',
  templateUrl: './superhero2.component.html',
  styleUrls: ['./superhero2.component.css']
})
export class Superhero2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

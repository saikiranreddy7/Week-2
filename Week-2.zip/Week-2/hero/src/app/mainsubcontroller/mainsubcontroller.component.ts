import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mainsubcontroller',
  templateUrl: './mainsubcontroller.component.html',
  styleUrls: ['./mainsubcontroller.component.css']
})
export class MainsubcontrollerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

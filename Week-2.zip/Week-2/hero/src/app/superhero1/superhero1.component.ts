import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-superhero1',
  templateUrl: './superhero1.component.html',
  styleUrls: ['./superhero1.component.css']
})
export class Superhero1Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
